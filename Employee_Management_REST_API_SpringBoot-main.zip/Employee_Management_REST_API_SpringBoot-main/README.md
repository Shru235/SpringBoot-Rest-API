# 🚀 Employee Management REST API

A production-style RESTful backend application built using **Spring Boot** and **MySQL** implementing full CRUD operations with layered architecture, validation, and global exception handling.

---

## 🛠 Tech Stack

- Java 17+
- Spring Boot
- Spring Data JPA (Hibernate)
- MySQL
- Maven
- Postman (API Testing)

---

## 🏗 Architecture

Layered architecture following best practices:

- Controller Layer
- Service Layer
- Repository Layer
- Model (Entity)
- Global Exception Handling
- Validation

---

## 📌 Features

- Create Employee
- Get All Employees
- Get Employee by ID
- Update Employee
- Delete Employee
- Field Validation
- Custom 404 Error Handling
- Proper HTTP Status Codes

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/employees | Create employee |
| GET | /api/employees | Get all employees |
| GET | /api/employees/{id} | Get employee by ID |
| PUT | /api/employees/{id} | Update employee |
| DELETE | /api/employees/{id} | Delete employee |

---

## 🧪 Sample Request (POST)

```json
{
  "name": "Raghav",
  "email": "raghav@example.com",
  "department": "IT",
  "salary": 50000
}
```

❌ Sample Validation Error
```json
{
  "email": "Email should be valid",
  "salary": "Salary must be positive"
}
```

▶️ How To Run
Clone repository
Configure MySQL in application.properties
Run: mvn spring-boot:run
Server runs on: http://localhost:8080

👨‍💻 Author
Raghav Maheshwari

---
