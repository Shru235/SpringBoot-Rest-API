package com.shrutiofficial.serviceslayer05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Serviceslayer05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
