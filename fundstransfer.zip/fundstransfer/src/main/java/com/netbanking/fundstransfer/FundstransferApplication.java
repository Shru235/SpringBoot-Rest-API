package com.netbanking.fundstransfer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundstransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundstransferApplication.class, args);
	}

}
