package com.netbanking.fundstransfer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundstransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
