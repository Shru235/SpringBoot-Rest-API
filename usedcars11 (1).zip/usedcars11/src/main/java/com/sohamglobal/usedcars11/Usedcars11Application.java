package com.sohamglobal.usedcars11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Usedcars11Application {

	public static void main(String[] args) {
		SpringApplication.run(Usedcars11Application.class, args);
		System.out.println("used cars project running...");
	}

}
