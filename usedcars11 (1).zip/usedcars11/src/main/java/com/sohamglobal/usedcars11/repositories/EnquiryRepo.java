package com.sohamglobal.usedcars11.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sohamglobal.usedcars11.entities.Enquiry;

public interface EnquiryRepo extends JpaRepository<Enquiry, Integer> {

}
