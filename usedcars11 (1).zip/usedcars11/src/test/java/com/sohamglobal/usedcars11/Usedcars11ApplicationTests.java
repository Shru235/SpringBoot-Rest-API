package com.sohamglobal.usedcars11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Usedcars11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
